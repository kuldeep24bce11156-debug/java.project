package edu.ccrm.domain;

//semester details

public enum Semester {
    SPRING, SUMMER, FALL;
}
